﻿SP2 Gun Lead Ring v0.5.0  /  机炮提前量环
==========================================

【安装 / Install】
1. SP2 自带 BepInEx，直接解压到游戏根目录合并覆盖即可：
   ...steamappscommonSimplePlanes 2BepInExpluginsSP2GunRing2. 启动游戏，进飞行场景。

【用法 / Usage】
锁定目标后准心旁出现一个环：
- 未对准色(默认白)  = 还没对准提前量
- 可开火色(默认绿)  = 机头已对准，开火必中
- 超限色(默认橙)    = 所需提前量超过 MaxOffsetPx，环被截在边界，需绕后/拉近
Pinned 模式下：环压到敌机身上那一刻，机头正好在提前量点上 —— 就是开火时机。

【配置 / Config】
Gravy Mod Menu -> "Gun Ring 机炮环"，或编辑 BepInExconfigsp2.gunring.cfg
所有选项都是数字，不需要输入文字。

General
  Enabled            1/0 总开关
  OnlyWhenSelected   1/0 只在锁定目标时显示
  MaxRange           目标搜索半径(m)
  MaxAngle           搜索锥角(度)
Visual
  Mode               0=Pinned(环贴准心)  1=Lead(环画在提前量点, 另显示机炮指向准心)
  Style              0=六条线  1=四条线  2=虚线圈  3=实心圆
  RingRadiusPx       环大小(像素)
  MaxOffsetPx        Pinned 模式环离准心最远像素, 0=不限
  ShowLine           1/0 准心到环的连线
  ShowGunCross       1/0 Lead 模式下的机炮指向准心
  GreenAngle         变绿条件: 机头与提前量点夹角<=该值(度)
  DebugDraw          1/0 调试标记与数值
Color
  IdleR/G/B          未对准颜色 0-255
  ReadyR/G/B         可开火颜色 0-255
  ClampedR/G/B       超限颜色 0-255
  Alpha              不透明度 0-255
Hit
  HitMarker / HitMarkerMs / HitMarkerPx   命中绿叉
  HitSound / HitVolume                    命中音效(hit.wav)
Menu
  PrintDiagnostics   勾一下=把当前测算写进日志
  TestHitSound       勾一下=播放命中音(测试用)

【说明 / Notes】
- 纯运行时插件，不改游戏文件，删除插件文件夹即卸载。
- hit.wav 可替换为任意 16bit PCM wav。
- 多人服务器上伤害在服务端结算，命中反馈可能不触发；环的提前量计算与服务器无关。


